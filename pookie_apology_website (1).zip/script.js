const intro = document.getElementById('intro');
const apology = document.getElementById('apology');
const ending = document.getElementById('ending');
const yesBtn = document.getElementById('yesBtn');
const noBtn = document.getElementById('noBtn');

function showScene(scene) {
  document.querySelectorAll('.scene').forEach(section => {
    section.classList.remove('active');
  });
  scene.classList.add('active');
}

// Show the apology after the opening message.
window.setTimeout(() => showScene(apology), 3500);

// The NO button jumps to a new safe position when approached or touched.
function moveNoButton() {
  const margin = 16;
  const rect = noBtn.getBoundingClientRect();
  const maxX = Math.max(margin, window.innerWidth - rect.width - margin);
  const maxY = Math.max(margin, window.innerHeight - rect.height - margin);

  let x = margin + Math.random() * (maxX - margin);
  let y = margin + Math.random() * (maxY - margin);

  const yesRect = yesBtn.getBoundingClientRect();
  for (let i = 0; i < 30; i++) {
    const overlapsYes =
      x < yesRect.right + 18 &&
      x + rect.width > yesRect.left - 18 &&
      y < yesRect.bottom + 18 &&
      y + rect.height > yesRect.top - 18;
    if (!overlapsYes) break;
    x = margin + Math.random() * (maxX - margin);
    y = margin + Math.random() * (maxY - margin);
  }

  noBtn.style.position = 'fixed';
  noBtn.style.left = `${x}px`;
  noBtn.style.top = `${y}px`;
}

noBtn.addEventListener('pointerenter', moveNoButton);
noBtn.addEventListener('pointerdown', event => {
  event.preventDefault();
  moveNoButton();
});
noBtn.addEventListener('click', event => {
  event.preventDefault();
  moveNoButton();
});

yesBtn.addEventListener('click', () => {
  showScene(ending);
});
